import React from "react";

export default function Header() {
  return (
    <>
      <h1>Profile Generator</h1>
      <p>Generate profile cards for Oasis members.</p>
    </>
  );
}
